document.body.style.margin = 0;

var container = document.createElement('div');
container.style.cssText = 'margin: 0 auto; min-width: 360px; max-width: 1230px; width: 100%; display: flex; justify-content: center; flex-wrap: wrap; font-family: Arial;';
document.body.appendChild(container);

catalog.forEach(el => {
    var prodInfo = document.createElement('div');
    prodInfo.style.cssText = 'width: 150px; min-height: 250px; border: 1px solid #f1f1f1; padding: 20px; margin: 20px; border-radius: 10px; background-repeat: no-repeat; background-position: center top 70px; display: flex; justify-content: space-between; flex-direction: column;';
    prodInfo.style.backgroundImage = 'url(' + el.miniature + ')';
    container.appendChild(prodInfo);

    var prodInfoTitle = document.createElement('span');
    prodInfoTitle.style.cssText = 'display: block; width: 100%; text-align: center; font-size: 17px; line-height: 1.2; min-height: 50px;';
    prodInfoTitle.innerText = el.title;
    prodInfo.appendChild(prodInfoTitle);

    var prodInfoPrice = document.createElement('span');
    prodInfoPrice.style.cssText = 'display: block; width: 100%; text-align: center; font-size: 17px; line-height: 1.2; min-height: 50px; height: 30px; padding-top: 140px;';
    prodInfoPrice.innerText = el.price + ' руб.';
    prodInfo.appendChild(prodInfoPrice);

    var prodInfoBtn = document.createElement('button');
    prodInfoBtn.style.cssText = 'width: 100%; height: 40px; outline: none; background-color: #363636; border-radius: 6px; border: 0; color: #fff; font-wight: 700;';
    prodInfoBtn.innerText = 'Посмотреть';
    prodInfoBtn.id = 'p' + catalog.indexOf(el);
    prodInfo.appendChild(prodInfoBtn);
});

var modalWin = document.createElement('div');
modalWin.id = 'mod1';
modalWin.style.cssText = 'position: fixed; z-index: 2; width: 600px; height: 300px; top:50px;display: none; transition: .5s; background-repeat: no-repeat; position: center; background-size: 100%; justify-content: space-between; align-items: center; text-shadow: 1px 1px 10px black; background-color: #f3f3f3;';
container.appendChild(modalWin);

var modalWinClose = document.createElement('span');
modalWinClose.innerText = '🞫';
modalWinClose.style.cssText = 'cursor: pointer; position: absolute; z-index: 2; text-align: right; color: #fff; display: none; font-weight: 700; top: 60px; right: 29%; text-shadow: 1px 1px 10px black; font-size: 20px';
container.appendChild(modalWinClose);

//элемент next
var modalWinNext = document.createElement('span');
modalWinNext.style.cssText = 'text-align: center; cursor: pointer; width: 30px; height: 30px; text-aline: center; color: #fff; font-size: 20px; transition: .5s;'
modalWinNext.id = 'left';
modalWinNext.innerText = '◀';
modalWin.appendChild(modalWinNext);

var modalWinNext = document.createElement('span');
modalWinNext.style.cssText = 'text-align: center; cursor: pointer; width: 30px; height: 30px; text-aline: center; color: #fff; font-size: 20px; transition: .5s;'
modalWinNext.id = 'right';
modalWinNext.innerText = '▶';
modalWin.appendChild(modalWinNext);

//каждой кнопке назначаем ожидание события click
var btn = document.getElementsByTagName('button');
for (let el of btn) {
    el.addEventListener('click', inBasket);
}

var selectBtn;
function inBasket(event) {
    let i = parseInt(this.id.match(/\d+/));
    j = 0;
    selectBtn = catalog[i];
    er(j);
    modalWin.style.backgroundImage = 'url(' + catalog[i].images[j] + ')';

    modalWin.style.display = 'flex';
    modalWinClose.style.display = 'inline';
}

function modalWinOut(event) {
    modalWin.style.display = 'none';
    modalWinClose.style.display = 'none';
}

var j = 0;
function next(event) {
    if (this.id == 'right') {
        if (j < selectBtn.images.length - 1) { j++; }
    }
    else {
        if (j > 0) { j--; }
    }

    modalWin.style.backgroundImage = 'url(' + selectBtn.images[j] + ')';

    er(j);
}

function er(r) {
    let img = document.createElement('img');
    img.src = selectBtn.images[r];
    console.log(img.src);
    img.onerror = function () { alert('Картинка не найдена'); }
}

modalWinClose.addEventListener('click', modalWinOut);
document.getElementById('right').addEventListener('click', next);
document.getElementById('left').addEventListener('click', next);
