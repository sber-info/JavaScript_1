var catalog = [
    bus = {
        title: 'Автобус',
        price: 1000,
        seat: 45,
        images: ['img/full_size/bus.jpg', 'img/full_size/bus_2.jpg'],
        miniature: 'img/miniature/bus.jpg',
    },

    minibus = {
        title: 'Микроватобус',
        price: 800,
        seat: 20,
        images: ['img/full_size/minibus.jpg', 'img/full_size/minibus_2.jpg'],
        miniature: 'img/miniature/minibus.jpg',
    },

    car = {
        title: 'Легковой автомобиль',
        price: 2500,
        seat: 4,
        images: ['img/full_size/car.jpg', 'img/full_size/car_2.jpg'],
        miniature: 'img/miniature/car.jpg',
    },
];